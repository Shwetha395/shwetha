# System-Health-Monitoring-Script--
Develop a script that monitors the health of a Linux system. 
It should check CPU usage, memory usage, disk space, and running processes. 
If any of these metrics exceed predefined thresholds (e.g., CPU usage &gt; 80%),the
script should send an alert to the console or a log file.
